classdef RAMA_CommonEmitter < audioPlugin
    % RAMA_CommonEmitter_Macro_UI
    % Fixed-host-rate MATLAB Audio Toolbox plugin for the RAMA common-emitter
    % amplifier benchmark.
    %
    % This version keeps the same RAMA processing pipeline and robust solver
    % scheme as the diode clipper demo, but replaces the raw transistor
    % parameters with safer macro controls for real-time use:
    %
    %   Drive, Level, Bias, Tone, Character, Heat, Feedback
    %
    % The numerical/debug settings are kept internal:
    %   gmin = 1e-9, SolverDamping = 1e-8.

    properties
        % Music/demo-facing controls
        Drive_dB = 0;       % Input drive before millivolt circuit scaling
        Level_dB = 0;       % Output trim
        Bias = 0.50;        % 0: lower headroom, 1: higher headroom
        Tone = 0.50;        % 0: darker, 1: brighter
        Character = 0.0;    % Virtual transistor morph
        Heat = 0.10;        % Effective device temperature macro
        Feedback = 0.45;    % Effective emitter degeneration macro
    end

    properties (Access = private)
        xState = zeros(3,2);
        qState = zeros(4,2);

        hSeconds = 1/44100;

        lastResidual = zeros(1,2);
        lastRcond = zeros(1,2);

        % Quiescent output estimate used to remove the DC operating point.
        yDC = zeros(1,2);
        dcA = 0;

        % Scaling and numerical regularization.
        inputScaleBase = 25e-3; % full-scale audio -> 25 mV nominal circuit signal
        outputScale = 0.25;
        gminVal = 1e-9;
        solverDampingVal = 1e-8;

        % Smoothed macro values.
        sDrive_dB = 0;
        sLevel_dB = 0;
        sBias = 0.50;
        sTone = 0.50;
        sCharacter = 0.0;
        sHeat = 0.10;
        sFeedback = 0.45;

        smoothA = 0;
    end

    properties (Constant)
        PluginInterface = audioPluginInterface( ...
            audioPluginParameter('Drive_dB', ...
                'DisplayName','Drive', ...
                'DisplayNameLocation','Above', ...
                'Label','dB', ...
                'Mapping',{'lin',-24,36}, ...
                'Style','rotaryknob', ...
                'Layout',[2,1]), ...
            audioPluginParameter('Level_dB', ...
                'DisplayName','Level', ...
                'DisplayNameLocation','Above', ...
                'Label','dB', ...
                'Mapping',{'lin',-36,12}, ...
                'Style','rotaryknob', ...
                'Layout',[2,2]), ...
            audioPluginParameter('Bias', ...
                'DisplayName','Bias', ...
                'DisplayNameLocation','Above', ...
                'Mapping',{'lin',0,1}, ...
                'Style','rotaryknob', ...
                'Layout',[2,3]), ...
            audioPluginParameter('Tone', ...
                'DisplayName','Tone', ...
                'DisplayNameLocation','Above', ...
                'Mapping',{'lin',0,1}, ...
                'Style','rotaryknob', ...
                'Layout',[2,4]), ...
            audioPluginParameter('Character', ...
                'DisplayName','Character', ...
                'DisplayNameLocation','Above', ...
                'Mapping',{'lin',0,1}, ...
                'Style','rotaryknob', ...
                'Layout',[4,1]), ...
            audioPluginParameter('Heat', ...
                'DisplayName','Heat', ...
                'DisplayNameLocation','Above', ...
                'Mapping',{'lin',0,1}, ...
                'Style','rotaryknob', ...
                'Layout',[4,2]), ...
            audioPluginParameter('Feedback', ...
                'DisplayName','Feedback', ...
                'DisplayNameLocation','Above', ...
                'Mapping',{'lin',0,1}, ...
                'Style','rotaryknob', ...
                'Layout',[4,3]), ...
            audioPluginGridLayout( ...
                'RowHeight',[22 76 18 76], ...
                'ColumnWidth',[96 96 96 96 96], ...
                'RowSpacing',4, ...
                'ColumnSpacing',10, ...
                'Padding',[19 5*19 19 19]*2), ...
            'PluginName','RAMA Common Emitter AMP', ...
            'VendorName','RAMA', ...
            'VendorVersion','0.1.0', ...
            'UniqueId','RaCE', ...
            'BackgroundImage','background2.png', ...
            'BackgroundColor',[223 237 237]/255);
    end

    methods
        function plugin = RAMA_CommonEmitter
            reset(plugin);
        end

        function reset(plugin)
            Fs = getSampleRate(plugin);
            plugin.hSeconds = 1/Fs;

            plugin.xState(:,:) = 0;
            plugin.qState(:,:) = 0;
            plugin.lastResidual(:) = 0;
            plugin.lastRcond(:) = 1;
            plugin.yDC(:) = 0;

            plugin.sDrive_dB = plugin.Drive_dB;
            plugin.sLevel_dB = plugin.Level_dB;
            plugin.sBias = plugin.Bias;
            plugin.sTone = plugin.Tone;
            plugin.sCharacter = plugin.Character;
            plugin.sHeat = plugin.Heat;
            plugin.sFeedback = plugin.Feedback;

            tau = 0.010;
            plugin.smoothA = exp(-1/(tau*Fs));

            tauDC = 0.50;
            plugin.dcA = exp(-1/(tauDC*Fs));

            % Settle the DC operating point silently to avoid a large startup
            % transient from the supply/bias input.
            warmupSteps = 128;
            for ch = 1:2
                x = plugin.xState(:,ch);
                q = plugin.qState(:,ch);
                for k = 1:warmupSteps
                    u = [0; effectiveBiasVoltage(plugin)];
                    [x, q, ~, ~] = takeOneStep(plugin, x, q, u, plugin.hSeconds);
                end
                u0 = [0; effectiveBiasVoltage(plugin)];
                plugin.yDC(ch) = outputEquation(plugin, x, q, u0);
                plugin.xState(:,ch) = x;
                plugin.qState(:,ch) = q;
            end
        end

        function out = process(plugin,in)
            out = zeros(size(in),'like',in);

            nCh = size(in,2);
            if nCh > 2
                nCh = 2;
            end

            h = plugin.hSeconds;

            for n = 1:size(in,1)
                updateSmoothedParameters(plugin);

                driveGain = 10^(plugin.sDrive_dB/20);
                levelGain = 10^(plugin.sLevel_dB/20);

                biasV = effectiveBiasVoltage(plugin);
                inputScale = effectiveInputScale(plugin);
                gainComp = effectiveGainCompensation(plugin);

                for ch = 1:nCh
                    % Normalized audio samples are mapped to a small circuit
                    % voltage before driving the common-emitter stage.
                    audioIn = inputScale * driveGain * double(in(n,ch));
                    audioIn = max(min(audioIn, 0.5), -0.5);

                    u = [audioIn; biasV];

                    [x, q, delta, rc] = takeOneStep(plugin, ...
                        plugin.xState(:,ch), plugin.qState(:,ch), u, h);

                    plugin.xState(:,ch) = x;
                    plugin.qState(:,ch) = q;
                    plugin.lastResidual(ch) = delta;
                    plugin.lastRcond(ch) = rc;

                    yRaw = outputEquation(plugin, x, q, u);

                    % Remove the quiescent operating point before converting
                    % circuit volts back to normalized audio.
                    y = yRaw - plugin.yDC(ch);
                    plugin.yDC(ch) = plugin.dcA*plugin.yDC(ch) + (1-plugin.dcA)*yRaw;

                    y = plugin.outputScale * gainComp * y;
                    y = max(min(y, 1.5), -1.5);
                    out(n,ch) = levelGain * y;
                end

                if size(in,2) > 2
                    out(n,3:end) = in(n,3:end);
                end
            end
        end
    end

    methods (Access = private)
        function updateSmoothedParameters(plugin)
            a = plugin.smoothA;
            b = 1 - a;
            plugin.sDrive_dB   = a*plugin.sDrive_dB   + b*plugin.Drive_dB;
            plugin.sLevel_dB   = a*plugin.sLevel_dB   + b*plugin.Level_dB;
            plugin.sBias       = a*plugin.sBias       + b*plugin.Bias;
            plugin.sTone       = a*plugin.sTone       + b*plugin.Tone;
            plugin.sCharacter  = a*plugin.sCharacter  + b*plugin.Character;
            plugin.sHeat       = a*plugin.sHeat       + b*plugin.Heat;
            plugin.sFeedback   = a*plugin.sFeedback   + b*plugin.Feedback;
        end

        function biasV = effectiveBiasVoltage(plugin)
            % Bias is a safe headroom macro.  The center value gives 9 V.
            b = max(min(plugin.sBias,1),0);
            biasV = 7.0 + 4.0*b;
        end

        function inputScale = effectiveInputScale(plugin)
            % Higher bias/headroom slightly reduces the internal drive so that
            % the Bias knob does not behave like a hidden gain boost.
            b = max(min(plugin.sBias,1),0);
            inputScale = plugin.inputScaleBase * (1.20 - 0.50*b);
        end

        function degen = effectiveDegeneration(plugin)
            % Feedback is mapped exponentially to an effective emitter
            % degeneration resistance.
            f = max(min(plugin.sFeedback,1),0);
            degen = exp(log(5) + f*(log(150)-log(5)));
        end

        function tempC = effectiveTemperature(plugin)
            h = max(min(plugin.sHeat,1),0);
            tempC = 20 + 50*h;
        end

        function gainComp = effectiveGainCompensation(plugin)
            % Crude but useful compensation so Character/Feedback changes are
            % easier to audition in real time.
            degen = effectiveDegeneration(plugin);
            betaF = effectiveBetaF(plugin);
            betaNorm = sqrt(300 / max(betaF, 50));
            degenNorm = sqrt(max(degen,1) / 22);
            gainComp = betaNorm * degenNorm;
            gainComp = max(min(gainComp, 3.0), 0.35);
        end

        function betaF = effectiveBetaF(plugin)
            c = max(min(plugin.sCharacter,1),0);
            betaFA = 300;
            betaFB = 120;
            betaF = exp((1-c)*log(betaFA) + c*log(betaFB));
            betaF = max(betaF, 1);
        end

        function [xNext, qNext, delta, rc] = takeOneStep(plugin, x, q, u, h)
            [A, B, G, H, D, E] = amplifierMatrices(plugin);
            [etaVal, J] = bjtEtaJac(plugin, q);

            dimx = 3;
            dimeta = 2;

            A1 = [eye(dimx) - A*h, -G*h];
            b1 = x + B*h*u;

            A2 = [-D, H];
            b2 = E*u;

            A3 = [zeros(dimeta,dimx), J];
            b3 = J*q - etaVal;

            Aeq = [A1; A2; A3];
            beq = [b1; b2; b3];

            [zNext, rc] = solveSmallSystem(plugin, Aeq, beq);

            xNext = zNext(1:3);
            qNext = zNext(4:7);

            etaNext = bjtEta(plugin, qNext);
            delta = norm(etaNext);
        end

        function [z, rc] = solveSmallSystem(plugin, Aeq, beq)
            nRows = size(Aeq,1);
            nCols = size(Aeq,2);

            rowScale = zeros(nRows,1);
            for i = 1:nRows
                s = sqrt(sum(Aeq(i,:).^2));
                rowScale(i) = 1 / max(s, 1e-12);
            end

            Arow = Aeq;
            brow = beq;
            for i = 1:nRows
                Arow(i,:) = rowScale(i) * Arow(i,:);
                brow(i) = rowScale(i) * brow(i);
            end

            colScale = zeros(nCols,1);
            for j = 1:nCols
                s = sqrt(sum(Arow(:,j).^2));
                colScale(j) = 1 / max(s, 1e-12);
            end

            As = Arow;
            for j = 1:nCols
                As(:,j) = colScale(j) * As(:,j);
            end

            rc = rcond(As);

            if rc > 1e-9
                y = As \ brow;
            else
                lambda = max(plugin.solverDampingVal, 1e-12) * norm(As,'fro')^2;
                y = As' * ((As*As' + lambda*eye(nRows)) \ brow);
            end

            z = zeros(nCols,1);
            for j = 1:nCols
                z(j) = colScale(j) * y(j);
            end
        end

        function [A, B, G, H, D, E] = amplifierMatrices(plugin)
            R1 = 100e3;
            R3 = 10e3;
            R4 = 470e3;
            R5 = 100e3;

            R2 = effectiveDegeneration(plugin);

            Cap1 = 0.047e-6;
            Cap2base = 250e-12;
            Cap3 = 0.47e-6;

            tone = max(min(plugin.sTone, 1), 0);
            % tone = 0 -> darker, larger Cap2. tone = 1 -> brighter.
            cap2Scale = 4^(1 - 2*tone);
            Cap2 = Cap2base * cap2Scale;

            A = [-(1/Cap1)*(1/R1+1/R3+1/R5), -(1/Cap1)*(1/R3+1/R5), -1/(R5*Cap1);
                 -(1/Cap2)*(1/R3+1/R5),      -(1/Cap2)*(1/R3+1/R5), -1/(R5*Cap2);
                 -1/(R5*Cap3),               -1/(R5*Cap3),          -1/(R5*Cap3)];

            B = [(1/Cap1)*(1/R1+1/R3+1/R5), -1/(R3*Cap1);
                 (1/Cap2)*(1/R3+1/R5),      -1/(R3*Cap2);
                 1/(R5*Cap3),                0];

            G = [0,            0, 1/Cap1,       0;
                 0, -1/(R4*Cap2),      0,  1/Cap2;
                 0,            0,      0,       0];

            H = [1, 0, R2, 0;
                 0, 1,  0, 0];

            D = [-1, 0, 0;
                  0, 1, 0];

            E = [1, 0;
                 0, 0];
        end

        function y = outputEquation(~, x, q, u) %#ok<INUSD>
            M = [-1, -1, -1];
            L = [1, 0];
            N = [0, 0, 0, 0];
            y = M*x + L*u + N*q;
        end

        function eta = bjtEta(plugin, q)
            [eta, ~] = bjtEtaJac(plugin, q);
        end

        function [eta, J] = bjtEtaJac(plugin, q)
            [VT, Is, betaF, betaR] = bjtParameters(plugin);
            gmin = plugin.gminVal;

            a1 = max(min(q(1)/VT, 60), -60);
            a2 = max(min(q(2)/VT, 60), -60);
            e1 = exp(a1);
            e2 = exp(a2);

            eta = [q(3) - (Is*((e1-e2) + (1/betaF)*(e1-1)) + gmin*q(1));
                   q(4) - (Is*((e1-e2) - (1/betaR)*(e2-1)) + gmin*q(2))];

            J = [-(Is/VT)*(1+1/betaF)*e1 - gmin,  (Is/VT)*e2,                         1, 0;
                 -(Is/VT)*e1,                     (Is/VT)*(1+1/betaR)*e2 - gmin,       0, 1];
        end

        function [VT, Is, betaF, betaR] = bjtParameters(plugin)
            VT25 = 26.0e-3;
            IsA = 6.734e-15;
            betaFA = 300;
            betaRA = 0.1;

            % Virtual endpoint for Character.
            IsB = 3.0e-14;
            betaFB = 120;
            betaRB = 0.05;

            c = max(min(plugin.sCharacter, 1), 0);

            tempC = effectiveTemperature(plugin);
            VT = VT25 * ((273.15 + tempC) / (273.15 + 25));

            % Mild temperature-dependent leakage increase for the Heat macro.
            h = max(min(plugin.sHeat,1),0);
            heatLeak = exp(0.75*h);

            Is = exp((1-c)*log(IsA) + c*log(IsB)) * heatLeak;

            betaF = exp((1-c)*log(betaFA) + c*log(betaFB));
            betaF = max(betaF, 1);

            betaR = exp((1-c)*log(betaRA) + c*log(betaRB));
            betaR = max(betaR, 1e-3);
        end
    end
end
